/**
 * m3-precificacao.js — Módulo 3: Precificação e Lucro Líquido
 *
 * Responsabilidades:
 *  - Tela de precificação por produto
 *  - Configuração de taxas Shopee e Mercado Livre
 *  - Cálculo de lucro líquido em R$ e %
 *  - Reage automaticamente a mudanças de preço de M2
 */

const M3 = (() => {

  /* ── Estado ────────────────────────────────────────────── */
  let pricing  = {};  // { [productId]: { sell_price, sell_qty } }
  let mktFees  = {
    shopee: { commission: 14, fixed: 0 },
    ml:     { commission: 12, fixed: 5 },
  };
  let activeProduct = null;
  let products = [];

  /* ── Persistência ──────────────────────────────────────── */
  function save() {
    Storage.set(Storage.KEYS.PRICING,  pricing);
    Storage.set(Storage.KEYS.MKT_FEES, mktFees);
  }

  function load() {
    pricing  = Storage.get(Storage.KEYS.PRICING,  {});
    mktFees  = Storage.get(Storage.KEYS.MKT_FEES, {
      shopee: { commission: 14, fixed: 0 },
      ml:     { commission: 12, fixed: 5 },
    });
  }

  /* ── Helpers ───────────────────────────────────────────── */

  /**
   * Calcula lucro líquido para um marketplace.
   * @param {number} sellPrice   — Preço de venda unitário
   * @param {number} unitCost    — Custo unitário real (M2)
   * @param {number} qty         — Quantidade vendida por transação
   * @param {{ commission: number, fixed: number }} fees
   * @returns {{ net: number, pct: number, breakdown: object }}
   */
  function calcProfit(sellPrice, unitCost, qty, fees) {
    const totalRevenue = sellPrice * qty;
    const totalCost    = unitCost  * qty;
    const commission   = totalRevenue * (Number(fees.commission) / 100);
    const fixed        = Number(fees.fixed);
    const net          = totalRevenue - totalCost - commission - fixed;
    const pct          = totalRevenue > 0 ? (net / totalRevenue) * 100 : 0;

    return {
      net,
      pct,
      breakdown: { totalRevenue, totalCost, commission, fixed }
    };
  }

  /* ── Renderização ──────────────────────────────────────── */

  function renderFees() {
    const el = (id) => document.getElementById(id);
    if (!el('m3-shopee-commission')) return;
    el('m3-shopee-commission').value = mktFees.shopee.commission;
    el('m3-shopee-fixed').value      = mktFees.shopee.fixed;
    el('m3-ml-commission').value     = mktFees.ml.commission;
    el('m3-ml-fixed').value          = mktFees.ml.fixed;
  }

  function renderProductList() {
    const list = document.getElementById('m3-product-list');
    if (!list) return;
    products = M2.getProducts();

    if (products.length === 0) {
      list.innerHTML = `<div class="empty-state" style="padding:16px">
        <i class="fa-solid fa-box-open"></i>
        <p>Cadastre produtos no Módulo 2</p>
      </div>`;
      return;
    }

    list.innerHTML = products.map(p => {
      const isActive = activeProduct === p.id;
      const typeBadge = p.type === 'Envelope'
        ? `<span class="badge badge-info" style="font-size:10px">COEX</span>`
        : `<span class="badge badge-warning" style="font-size:10px">PEBD</span>`;

      return `
        <div class="m3-prod-item ${isActive ? 'active' : ''}"
             onclick="M3.selectProduct('${p.id}')">
          <div>
            <div style="font-size:13px;font-weight:600">${Utils.esc(p.name)}</div>
            <div class="mt-1">${typeBadge}</div>
          </div>
          <i class="fa-solid fa-chevron-right" style="font-size:11px;color:var(--text-sec)"></i>
        </div>
      `;
    }).join('');
  }

  function renderPricingPanel() {
    const panel = document.getElementById('m3-pricing-panel');
    const emptyState = document.getElementById('m3-empty');
    if (!panel || !emptyState) return;

    if (!activeProduct) {
      panel.classList.add('hidden');
      emptyState.classList.remove('hidden');
      return;
    }

    panel.classList.remove('hidden');
    emptyState.classList.add('hidden');

    const product = products.find(p => p.id === activeProduct);
    if (!product) return;

    const unitCost = M2.getUnitCost(activeProduct);
    const pd       = pricing[activeProduct] || { sell_price: 0, sell_qty: 1 };

    // Preenche campos
    document.getElementById('m3-prod-title').textContent      = product.name;
    document.getElementById('m3-unit-cost').textContent       = Utils.brl(unitCost);
    document.getElementById('m3-sell-price').value            = pd.sell_price || '';
    document.getElementById('m3-sell-qty').value              = pd.sell_qty   || 1;

    // Calcula e renderiza
    calcAndRender();
  }

  function calcAndRender() {
    if (!activeProduct) return;
    const product = products.find(p => p.id === activeProduct);
    if (!product) return;

    const unitCost  = M2.getUnitCost(activeProduct);
    const sellPrice = parseFloat(document.getElementById('m3-sell-price')?.value) || 0;
    const qty       = parseInt(document.getElementById('m3-sell-qty')?.value)     || 1;

    const shopeeResult = calcProfit(sellPrice, unitCost, qty, mktFees.shopee);
    const mlResult     = calcProfit(sellPrice, unitCost, qty, mktFees.ml);

    renderProfitCard('shopee', shopeeResult, sellPrice, qty);
    renderProfitCard('ml',     mlResult,     sellPrice, qty);
  }

  function renderProfitCard(marketplace, result, sellPrice, qty) {
    const prefix = `m3-${marketplace}`;
    const valEl  = document.getElementById(`${prefix}-net`);
    const pctEl  = document.getElementById(`${prefix}-pct`);
    const bkEl   = document.getElementById(`${prefix}-breakdown`);
    if (!valEl) return;

    const isPositive = result.net >= 0;
    valEl.textContent = Utils.brl(result.net);
    valEl.className   = `profit-value ${isPositive ? 'positive' : 'negative'}`;
    pctEl.textContent = `${Utils.num(result.pct, 2)}% de margem`;
    pctEl.className   = `profit-pct ${isPositive ? 'positive' : 'negative'}`;

    if (bkEl) {
      const bk = result.breakdown;
      bkEl.innerHTML = `
        Receita total: <span>${Utils.brl(bk.totalRevenue)}</span><br>
        Custo total:   <span>- ${Utils.brl(bk.totalCost)}</span><br>
        Comissão:      <span>- ${Utils.brl(bk.commission)}</span><br>
        Taxa fixa:     <span>- ${Utils.brl(bk.fixed)}</span>
      `;
    }
  }

  /* ── Ações ─────────────────────────────────────────────── */

  function saveFees() {
    const el = (id) => parseFloat(document.getElementById(id)?.value) || 0;
    mktFees = {
      shopee: { commission: el('m3-shopee-commission'), fixed: el('m3-shopee-fixed') },
      ml:     { commission: el('m3-ml-commission'),     fixed: el('m3-ml-fixed')     },
    };
    save();
    calcAndRender();
    Toast.success('Taxas dos marketplaces salvas.');
  }

  function selectProduct(id) {
    activeProduct = id;
    renderProductList();
    renderPricingPanel();
  }

  function savePricingInputs() {
    if (!activeProduct) return;
    const sellPrice = parseFloat(document.getElementById('m3-sell-price')?.value) || 0;
    const sellQty   = parseInt(document.getElementById('m3-sell-qty')?.value)     || 1;
    pricing[activeProduct] = { sell_price: sellPrice, sell_qty: sellQty };
    save();
    calcAndRender();
  }

  /* ── Inicialização ─────────────────────────────────────── */
  function init() {
    load();

    // Salvar taxas
    const saveFeesBtn = document.getElementById('m3-save-fees-btn');
    if (saveFeesBtn) saveFeesBtn.addEventListener('click', saveFees);

    // Live calc ao digitar preço/qtd
    ['m3-sell-price', 'm3-sell-qty'].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('input', () => {
          savePricingInputs();
        });
      }
    });

    // Reage a atualização de preços do M2
    document.addEventListener('m2:prices:updated',   () => {
      products = M2.getProducts();
      calcAndRender();
      document.getElementById('m3-unit-cost') &&
        (document.getElementById('m3-unit-cost').textContent = Utils.brl(M2.getUnitCost(activeProduct)));
    });

    // Reage a atualização de produtos do M2
    document.addEventListener('m2:products:updated', () => {
      products = M2.getProducts();
      renderProductList();
      if (activeProduct && !products.find(p => p.id === activeProduct)) {
        activeProduct = null;
      }
      renderPricingPanel();
    });

    document.addEventListener('route:change', (e) => {
      if (e.detail.route === 'm3') {
        load();
        products = M2.getProducts();
        renderFees();
        renderProductList();
        renderPricingPanel();
      }
    });

    renderFees();
  }

  return {
    init,
    selectProduct,
    saveFees,
    savePricingInputs,
    calcAndRender,
  };

})();
