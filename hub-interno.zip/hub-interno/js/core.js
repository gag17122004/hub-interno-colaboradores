/**
 * core.js — Hub Interno
 * Responsabilidades:
 *  - Abstração do LocalStorage (Storage)
 *  - Utilitários globais (formatação, datas)
 *  - Sistema de Toasts
 *  - Sistema de Modal
 *  - Alternância de Tema
 *  - Roteamento entre módulos (sidebar)
 *  - Inicialização da aplicação
 */

/* ============================================================
   1. STORAGE — Abstração do LocalStorage
   ============================================================ */
const Storage = {
  /**
   * Lê e desserializa um item.
   * @param {string} key
   * @param {*} fallback — valor padrão se a chave não existir
   */
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      return raw !== null ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.warn(`[Storage.get] Erro ao ler "${key}":`, e);
      return fallback;
    }
  },

  /**
   * Serializa e salva um item.
   * @param {string} key
   * @param {*} value
   */
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`[Storage.set] Erro ao salvar "${key}":`, e);
      Toast.error('Erro ao salvar dados. LocalStorage pode estar cheio.');
    }
  },

  /**
   * Remove um item.
   * @param {string} key
   */
  remove(key) {
    localStorage.removeItem(key);
  },

  // Chaves centralizadas — evita typos espalhados pelo código
  KEYS: {
    THEME:        'hub_theme',
    EMPLOYEES:    'hub_employees',
    HOURS:        'hub_hours',       // { [employeeId]: [{ id, date, hours, period }] }
    DEBTS:        'hub_debts',       // { [employeeId]: number }
    RAW_PRICES:   'hub_raw_prices',  // { coex: number, pebd: number }
    PRODUCTS:     'hub_products',    // [{ id, name, type, weight }]
    MKT_FEES:     'hub_mkt_fees',    // { shopee: { commission, fixed }, ml: { commission, fixed } }
    PRICING:      'hub_pricing',     // { [productId]: { shopee_price, ml_price, sell_qty } }
    TASKS:        'hub_tasks',       // [{ id, date, item, notes }]
  }
};

/* ============================================================
   2. UTILS — Funções utilitárias globais
   ============================================================ */
const Utils = {
  /**
   * Gera um ID único simples.
   */
  uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  },

  /**
   * Formata número como moeda BRL.
   * @param {number} value
   */
  brl(value) {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);
  },

  /**
   * Formata número com casas decimais.
   * @param {number} value
   * @param {number} decimals
   */
  num(value, decimals = 2) {
    return Number(value || 0).toFixed(decimals);
  },

  /**
   * Formata data ISO (YYYY-MM-DD) para DD/MM/YYYY.
   * @param {string} iso
   */
  fmtDate(iso) {
    if (!iso) return '—';
    const [y, m, d] = iso.split('-');
    return `${d}/${m}/${y}`;
  },

  /**
   * Retorna o nome do dia da semana para uma data ISO.
   * @param {string} iso — YYYY-MM-DD
   * @returns {'weekday'|'weekend'}
   */
  dayType(iso) {
    if (!iso) return 'weekday';
    // Usar T12:00:00 para evitar problemas de fuso
    const d = new Date(`${iso}T12:00:00`);
    const dow = d.getDay(); // 0=Dom, 6=Sáb
    return (dow === 0 || dow === 6) ? 'weekend' : 'weekday';
  },

  /**
   * Calcula o período de hora extra para dias úteis.
   * Início fixo: 16:00. Soma as horas informadas.
   * @param {number} hours — Ex: 1.5
   * @returns {string} — Ex: "16:00 ÀS 17:30"
   */
  calcPeriod(hours) {
    const startMinutes = 16 * 60; // 16:00 em minutos
    const endMinutes   = startMinutes + Math.round(Number(hours) * 60);
    const fmtTime = (mins) => {
      const h = Math.floor(mins / 60).toString().padStart(2, '0');
      const m = (mins % 60).toString().padStart(2, '0');
      return `${h}:${m}`;
    };
    return `${fmtTime(startMinutes)} ÀS ${fmtTime(endMinutes)}`;
  },

  /**
   * Sanitiza string para evitar XSS ao inserir no DOM.
   * @param {string} str
   */
  esc(str) {
    const d = document.createElement('div');
    d.textContent = str ?? '';
    return d.innerHTML;
  },

  /**
   * Retorna o mês/ano atual no formato YYYY-MM para uso em filtros.
   */
  currentMonth() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  },

  /**
   * Converte "YYYY-MM" para "Mês/YYYY" em português.
   * @param {string} ym — YYYY-MM
   */
  fmtMonth(ym) {
    if (!ym) return '';
    const months = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                    'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    const [y, m] = ym.split('-');
    return `${months[parseInt(m, 10) - 1]} / ${y}`;
  }
};

/* ============================================================
   3. TOAST — Notificações não-intrusivas
   ============================================================ */
const Toast = {
  _container: null,

  _init() {
    if (!this._container) {
      this._container = document.getElementById('toast-container');
    }
  },

  _show(message, type = 'info', duration = 3200) {
    this._init();
    const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', info: 'fa-circle-info' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i> ${Utils.esc(message)}`;
    this._container.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(6px)';
      el.style.transition = '.2s ease';
      setTimeout(() => el.remove(), 220);
    }, duration);
  },

  success(msg, duration) { this._show(msg, 'success', duration); },
  error(msg, duration)   { this._show(msg, 'error',   duration); },
  info(msg, duration)    { this._show(msg, 'info',    duration); },
};

/* ============================================================
   4. MODAL — Diálogo de confirmação/formulário genérico
   ============================================================ */
const Modal = {
  _el:  null,
  _title: null,
  _body:  null,
  _confirmBtn: null,
  _cancelBtn:  null,
  _onConfirm: null,

  _init() {
    if (this._el) return;
    this._el         = document.getElementById('global-modal');
    this._title      = document.getElementById('modal-title');
    this._body       = document.getElementById('modal-body');
    this._confirmBtn = document.getElementById('modal-confirm');
    this._cancelBtn  = document.getElementById('modal-cancel');

    this._cancelBtn.addEventListener('click', () => this.close());
    this._el.addEventListener('click', (e) => {
      if (e.target === this._el) this.close();
    });
    this._confirmBtn.addEventListener('click', () => {
      if (typeof this._onConfirm === 'function') this._onConfirm();
      this.close();
    });
  },

  /**
   * Abre o modal de confirmação.
   * @param {object} opts
   * @param {string}   opts.title
   * @param {string}   opts.body       — HTML permitido
   * @param {string}   [opts.confirmText]
   * @param {string}   [opts.confirmClass]
   * @param {Function} [opts.onConfirm]
   */
  confirm({ title, body, confirmText = 'Confirmar', confirmClass = 'btn-danger', onConfirm }) {
    this._init();
    this._title.textContent       = title;
    this._body.innerHTML          = body;
    this._confirmBtn.textContent  = confirmText;
    this._confirmBtn.className    = `btn ${confirmClass}`;
    this._onConfirm               = onConfirm;
    this._el.classList.add('open');
  },

  close() {
    this._init();
    this._el.classList.remove('open');
    this._onConfirm = null;
  }
};

/* ============================================================
   5. TEMA — Alternância dark/light
   ============================================================ */
const Theme = {
  _current: 'dark',

  init() {
    this._current = Storage.get(Storage.KEYS.THEME, 'dark');
    this._apply();
    document.getElementById('theme-toggle').addEventListener('click', () => this.toggle());
  },

  toggle() {
    this._current = this._current === 'dark' ? 'light' : 'dark';
    Storage.set(Storage.KEYS.THEME, this._current);
    this._apply();
  },

  _apply() {
    document.documentElement.setAttribute('data-theme', this._current);
    const pill = document.getElementById('theme-pill');
    const label = document.getElementById('theme-label');
    if (pill)  pill.className  = `toggle-pill ${this._current === 'light' ? 'on' : ''}`;
    if (label) label.textContent = this._current === 'dark' ? 'Tema Escuro' : 'Tema Claro';
  }
};

/* ============================================================
   6. ROUTER — Navegação entre módulos via sidebar
   ============================================================ */
const Router = {
  _current: null,

  init() {
    document.querySelectorAll('[data-route]').forEach(item => {
      item.addEventListener('click', () => this.navigate(item.dataset.route));
    });
    // Rota inicial
    const initial = window.location.hash.replace('#', '') || 'm1';
    this.navigate(initial);
  },

  navigate(route) {
    // Atualiza sidebar
    document.querySelectorAll('[data-route]').forEach(item => {
      item.classList.toggle('active', item.dataset.route === route);
    });

    // Mostra painel correto
    document.querySelectorAll('.module-panel').forEach(panel => {
      panel.classList.toggle('active', panel.id === `panel-${route}`);
    });

    // Atualiza topbar
    const navItem = document.querySelector(`[data-route="${route}"]`);
    if (navItem) {
      document.getElementById('topbar-title').textContent =
        navItem.querySelector('span')?.textContent || '';
      document.getElementById('topbar-sub').textContent =
        navItem.dataset.sub || '';
    }

    this._current = route;
    window.location.hash = route;

    // Dispara evento para que cada módulo possa reagir (ex: re-renderizar)
    document.dispatchEvent(new CustomEvent('route:change', { detail: { route } }));
  }
};

/* ============================================================
   7. APP — Inicialização global
   ============================================================ */
const App = {
  init() {
    Theme.init();
    Router.init();

    // Inicializa cada módulo na ordem
    M1.init();
    M2.init();
    M3.init();
    M4.init();
    M5.init();

    console.info('[Hub Interno] Aplicação iniciada com sucesso.');
  }
};

// Aguarda o DOM estar pronto
document.addEventListener('DOMContentLoaded', () => App.init());
