/**
 * m2-custos.js — Módulo 2: Custos, Matéria-Prima e Produtos
 *
 * Responsabilidades:
 *  - Gerenciar preços por kg do COEX e PEBD
 *  - CRUD de produtos (nome, tipo, peso)
 *  - Cálculo automático de custos (unitário, Pratik, lote)
 *  - Notificar M3 sempre que os preços mudarem
 */

const M2 = (() => {

  /* ── Estado ────────────────────────────────────────────── */
  let rawPrices = { coex: 0, pebd: 0 };
  let products  = [];

  const LOSS_MARGIN = 1.05; // 5% de variabilidade/perda

  /* ── Persistência ──────────────────────────────────────── */
  function save() {
    Storage.set(Storage.KEYS.RAW_PRICES, rawPrices);
    Storage.set(Storage.KEYS.PRODUCTS,   products);
  }

  function load() {
    rawPrices = Storage.get(Storage.KEYS.RAW_PRICES, { coex: 0, pebd: 0 });
    products  = Storage.get(Storage.KEYS.PRODUCTS,   []);
  }

  /* ── Cálculos ──────────────────────────────────────────── */

  /**
   * Retorna o preço/kg correto para o tipo do produto.
   * @param {'Envelope'|'Saco'} type
   */
  function priceForType(type) {
    return type === 'Envelope' ? Number(rawPrices.coex) : Number(rawPrices.pebd);
  }

  /**
   * Calcula todos os custos de um produto.
   * @param {{ type: string, weight: number }} product
   * @returns {{ unitReal: number, pratik: number, lote: number, loteQty: number }}
   */
  function calcCosts(product) {
    const kg    = Number(product.weight) || 0;
    const price = priceForType(product.type);

    const unitReal = kg * price * LOSS_MARGIN;             // Custo unitário real
    const pratik   = kg * price * 2;                        // Custo Pratik
    const loteQty  = product.type === 'Envelope' ? 1000 : 100;
    const lote     = unitReal * loteQty;

    return { unitReal, pratik, lote, loteQty };
  }

  /* ── Renderização ──────────────────────────────────────── */

  function renderPrices() {
    const coexInput = document.getElementById('m2-price-coex');
    const pebdInput = document.getElementById('m2-price-pebd');
    if (coexInput) coexInput.value = rawPrices.coex || '';
    if (pebdInput) pebdInput.value = rawPrices.pebd || '';
  }

  function renderProducts() {
    const tbody = document.getElementById('m2-products-tbody');
    if (!tbody) return;

    if (products.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="empty-state">
        <i class="fa-solid fa-box-open"></i>
        <p>Nenhum produto cadastrado.</p>
      </td></tr>`;
      return;
    }

    tbody.innerHTML = products.map(p => {
      const costs = calcCosts(p);
      const priceKg = priceForType(p.type);
      const typeBadge = p.type === 'Envelope'
        ? `<span class="badge badge-info">Envelope (COEX)</span>`
        : `<span class="badge badge-warning">Saco (PEBD)</span>`;
      const lotLabel = p.type === 'Envelope' ? 'Milheiro' : '100 un.';

      return `
        <tr>
          <td><strong>${Utils.esc(p.name)}</strong></td>
          <td>${typeBadge}</td>
          <td class="font-mono">${Utils.num(p.weight, 4)} kg</td>
          <td class="font-mono">${Utils.brl(priceKg)}/kg</td>
          <td class="font-mono text-accent">${Utils.brl(costs.unitReal)}</td>
          <td class="font-mono">${Utils.brl(costs.pratik)}</td>
          <td class="font-mono">
            ${Utils.brl(costs.lote)}
            <span class="text-xs text-muted">(${lotLabel})</span>
          </td>
          <td>
            <div class="flex gap-2">
              <button class="btn btn-xs btn-secondary" onclick="M2.editProduct('${p.id}')">
                <i class="fa-solid fa-pen"></i>
              </button>
              <button class="btn btn-xs btn-danger" onclick="M2.removeProduct('${p.id}')">
                <i class="fa-solid fa-trash"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  /* ── Ações ─────────────────────────────────────────────── */

  function savePrices() {
    const coex = parseFloat(document.getElementById('m2-price-coex').value);
    const pebd = parseFloat(document.getElementById('m2-price-pebd').value);

    if (isNaN(coex) || coex < 0) { Toast.error('Preço COEX inválido.'); return; }
    if (isNaN(pebd) || pebd < 0) { Toast.error('Preço PEBD inválido.'); return; }

    rawPrices = { coex, pebd };
    save();
    renderProducts();

    // Notifica M3 para recalcular preços
    document.dispatchEvent(new CustomEvent('m2:prices:updated'));
    Toast.success('Preços por kg atualizados e custos recalculados.');
  }

  let _editingProductId = null;

  function openAddProduct() {
    _editingProductId = null;
    document.getElementById('m2-prod-modal-title').textContent = 'Novo Produto';
    document.getElementById('m2-prod-name').value   = '';
    document.getElementById('m2-prod-type').value   = 'Envelope';
    document.getElementById('m2-prod-weight').value = '';
    document.getElementById('modal-product').classList.add('open');
  }

  function editProduct(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;
    _editingProductId = id;
    document.getElementById('m2-prod-modal-title').textContent = 'Editar Produto';
    document.getElementById('m2-prod-name').value   = product.name;
    document.getElementById('m2-prod-type').value   = product.type;
    document.getElementById('m2-prod-weight').value = product.weight;
    document.getElementById('modal-product').classList.add('open');
  }

  function closeProductModal() {
    document.getElementById('modal-product').classList.remove('open');
    _editingProductId = null;
  }

  function saveProduct() {
    const name   = document.getElementById('m2-prod-name').value.trim();
    const type   = document.getElementById('m2-prod-type').value;
    const weight = parseFloat(document.getElementById('m2-prod-weight').value);

    if (!name)                    { Toast.error('Informe o nome do produto.'); return; }
    if (isNaN(weight) || weight <= 0) { Toast.error('Informe o peso unitário (kg).'); return; }

    if (_editingProductId) {
      const idx = products.findIndex(p => p.id === _editingProductId);
      if (idx !== -1) products[idx] = { ...products[idx], name, type, weight };
    } else {
      products.push({ id: Utils.uid(), name, type, weight });
    }

    save();
    closeProductModal();
    renderProducts();

    // M3 precisa saber que os produtos mudaram
    document.dispatchEvent(new CustomEvent('m2:products:updated'));
    Toast.success(_editingProductId ? 'Produto atualizado.' : 'Produto cadastrado.');
  }

  function removeProduct(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;
    Modal.confirm({
      title: 'Remover Produto',
      body: `<p>Remover <strong>${Utils.esc(product.name)}</strong>?</p>
             <p class="text-sm text-muted mt-2">Os dados de precificação deste produto também serão removidos.</p>`,
      confirmText: 'Remover',
      confirmClass: 'btn-danger',
      onConfirm() {
        products = products.filter(p => p.id !== id);
        // Remove precificação associada
        const pricing = Storage.get(Storage.KEYS.PRICING, {});
        delete pricing[id];
        Storage.set(Storage.KEYS.PRICING, pricing);
        save();
        renderProducts();
        document.dispatchEvent(new CustomEvent('m2:products:updated'));
        Toast.success('Produto removido.');
      }
    });
  }

  /* ── API para outros módulos ───────────────────────────── */

  /** Retorna todos os produtos (usado por M3). */
  function getProducts() {
    return [...products];
  }

  /** Retorna os preços de matéria-prima (usado por M3). */
  function getRawPrices() {
    return { ...rawPrices };
  }

  /**
   * Retorna o custo unitário real de um produto pelo ID.
   * @param {string} productId
   */
  function getUnitCost(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return 0;
    return calcCosts(product).unitReal;
  }

  /* ── Inicialização ─────────────────────────────────────── */
  function init() {
    load();

    const savePricesBtn = document.getElementById('m2-save-prices-btn');
    if (savePricesBtn) savePricesBtn.addEventListener('click', savePrices);

    const addProductBtn = document.getElementById('m2-add-product-btn');
    if (addProductBtn) addProductBtn.addEventListener('click', openAddProduct);

    const saveProductBtn = document.getElementById('m2-save-product-btn');
    if (saveProductBtn) saveProductBtn.addEventListener('click', saveProduct);

    const cancelProductBtn = document.getElementById('m2-cancel-product-btn');
    if (cancelProductBtn) cancelProductBtn.addEventListener('click', closeProductModal);

    renderPrices();
    renderProducts();

    document.addEventListener('route:change', (e) => {
      if (e.detail.route === 'm2') {
        load();
        renderPrices();
        renderProducts();
      }
    });
  }

  return {
    init,
    savePrices,
    openAddProduct,
    editProduct,
    closeProductModal,
    saveProduct,
    removeProduct,
    getProducts,
    getRawPrices,
    getUnitCost,
  };

})();
